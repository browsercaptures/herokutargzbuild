. env.sh

node server.js