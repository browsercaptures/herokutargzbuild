. p.sh $*

. h.sh setconfig
. h.sh build
