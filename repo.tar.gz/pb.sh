. p.sh $*

. h.sh build